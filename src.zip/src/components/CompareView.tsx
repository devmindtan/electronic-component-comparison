import React from 'react';
import {
  X,
  CheckCircle,
  XCircle,
  Minus,
  ExternalLink,
  GitCompare,
  Thermometer,
  Zap,
  Package,
  Shield,
  Cpu,
} from 'lucide-react';
import type { Component } from '../lib/supabase';
import { formatSpecKey, formatSpecValue, getSpecDiff, getAllSpecKeys } from '../lib/utils';
import { getComponentImage } from '../lib/images';
import { Badge } from './ui/Badge';
import { Button } from './ui/Button';
import { cn } from '../lib/cn';

interface CompareDrawerProps {
  components: Component[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onOpenTable: () => void;
}

export function CompareDrawer({ components, onRemove, onClear, onOpenTable }: CompareDrawerProps) {
  if (components.length === 0) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-sm border-t border-gray-200 shadow-[0_-4px_24px_rgba(0,0,0,0.07)]">
      <div className="max-w-screen-xl mx-auto px-4 py-2.5 flex items-center gap-3">
        {/* Left: label + chips */}
        <div className="flex items-center gap-2.5 flex-1 min-w-0 overflow-x-auto scrollbar-hide">
          <span className="flex items-center gap-1.5 text-xs text-gray-400 whitespace-nowrap shrink-0">
            <GitCompare size={13} className="text-blue-500" />
            <span className="text-blue-600 font-medium">{components.length}</span>
            <span>/4</span>
          </span>

          {components.map((c) => (
            <span
              key={c.id}
              className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-full px-3 py-1 text-xs font-medium whitespace-nowrap shrink-0"
            >
              {c.name}
              <button
                onClick={() => onRemove(c.id)}
                className="text-blue-400 hover:text-red-500 transition-colors ml-0.5"
                aria-label={`Remove ${c.name}`}
              >
                <X size={10} />
              </button>
            </span>
          ))}

          {components.length < 2 && (
            <span className="text-xs text-gray-400 whitespace-nowrap shrink-0">
              Select {2 - components.length} more to compare
            </span>
          )}
        </div>

        {/* Right: actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onClear}
            className="text-xs text-gray-400 hover:text-gray-600 transition-colors px-2 py-1 rounded-md hover:bg-gray-100"
          >
            Clear
          </button>
          {components.length >= 2 && (
            <button
              onClick={onOpenTable}
              className="inline-flex items-center gap-1.5 bg-gray-900 text-white text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors"
            >
              <GitCompare size={12} />
              Compare ({components.length})
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

interface CompareTableProps {
  components: Component[];
  onRemove: (id: string) => void;
  onClose: () => void;
}

export function CompareTable({ components, onRemove, onClose }: CompareTableProps) {
  if (components.length === 0) return null;

  const allKeys = getAllSpecKeys(components.map((c) => c.specs));
  const allSpecs = components.map((c) => c.specs);

  const physicalRows: {
    label: string;
    icon?: React.ReactNode;
    get: (c: Component) => unknown;
  }[] = [
    {
      label: 'Package type',
      icon: <Package size={12} />,
      get: (c) => c.package_type,
    },
    {
      label: 'Dimensions',
      icon: null,
      get: (c) => c.dimensions_mm,
    },
    {
      label: 'Operating temp',
      icon: <Thermometer size={12} />,
      get: (c) =>
        c.operating_temp_min != null && c.operating_temp_max != null
          ? `${c.operating_temp_min}°C to ${c.operating_temp_max}°C`
          : null,
    },
    {
      label: 'Supply voltage',
      icon: <Zap size={12} />,
      get: (c) =>
        c.voltage_min != null && c.voltage_max != null
          ? `${c.voltage_min}V – ${c.voltage_max}V`
          : null,
    },
    {
      label: 'RoHS compliant',
      icon: <Shield size={12} />,
      get: (c) => c.rohs_compliant,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-auto scrollbar-hide bg-gray-50">
      {/* Sticky top bar */}
      <div className="sticky top-0 z-20 bg-white border-b border-gray-200">
        <div className="max-w-screen-xl mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GitCompare size={16} className="text-blue-500" />
            <h2 className="text-sm font-medium text-gray-900">Compare</h2>
            <span className="inline-flex items-center bg-blue-50 text-blue-600 border border-blue-200 text-xs font-medium rounded-full px-2 py-0.5">
              {components.length} component{components.length !== 1 ? 's' : ''}
            </span>
          </div>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-1.5 text-xs text-gray-500 border border-gray-200 rounded-lg px-3 py-1.5 hover:bg-gray-50 transition-colors"
          >
            <X size={12} />
            Close
          </button>
        </div>

        {/* Component header cards */}
        <div className="max-w-screen-xl mx-auto px-5 pb-4 overflow-x-auto">
          <div className="flex gap-3" style={{ minWidth: `${160 + components.length * 200}px` }}>
            {/* Spacer aligns with the label column */}
            <div className="w-40 shrink-0" />
            {components.map((c) => (
              <div key={c.id} className="flex-1 min-w-[160px] relative">
                <div className="bg-white border border-gray-200 rounded-xl p-3 relative">
                  <button
                    onClick={() => onRemove(c.id)}
                    className="absolute top-2.5 right-2.5 p-1 rounded-md text-gray-300 hover:text-red-500 hover:bg-red-50 transition-colors"
                    aria-label={`Remove ${c.name}`}
                  >
                    <X size={11} />
                  </button>
                  {/* Image or fallback */}
                  <div className="w-full h-14 rounded-lg mb-2.5 overflow-hidden bg-gray-50 flex items-center justify-center">
                    {getComponentImage(c) ? (
                      <img
                        src={getComponentImage(c)}
                        alt={c.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Cpu size={20} className="text-gray-300" />
                    )}
                  </div>
                  <p className="text-xs font-medium text-gray-900 leading-snug pr-5 truncate">
                    {c.name}
                  </p>
                  <p className="text-[11px] text-gray-400 mt-0.5 truncate">{c.manufacturer}</p>
                  {c.rohs_compliant && (
                    <div className="mt-2">
                      <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-600 border border-blue-200 text-[10px] font-medium rounded-full px-2 py-0.5">
                        <Shield size={8} /> RoHS
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Table body */}
      <div className="max-w-screen-xl mx-auto px-5 py-4 space-y-3">
        {/* General Information */}
        <Section title="General information">
          {[
            { label: 'Manufacturer', get: (c: Component) => c.manufacturer || '—' },
            { label: 'Series', get: (c: Component) => c.series || '—' },
            { label: 'Category', get: (c: Component) => c.categories?.name || '—' },
            { label: 'Part number', get: (c: Component) => c.part_number || c.name },
            { label: 'Description', get: (c: Component) => c.description || '—' },
          ].map((row) => {
            const vals = components.map(row.get);
            const isDiff = vals.some((v) => v !== vals[0]);
            return (
              <Row key={row.label} label={row.label} isDiff={isDiff}>
                {components.map((c) => (
                  <Cell key={c.id} isDiff={isDiff}>
                    <span className="line-clamp-2">{row.get(c)}</span>
                  </Cell>
                ))}
              </Row>
            );
          })}
        </Section>

        {/* Physical & Environmental */}
        <Section title="Physical & environmental">
          {physicalRows.map((row) => {
            const vals = components.map((c) => row.get(c));
            const defined = vals.filter((v) => v !== null && v !== undefined);
            const isDiff =
              defined.length > 1 && !defined.every((v) => String(v) === String(defined[0]));
            return (
              <Row key={row.label} label={row.label} isDiff={isDiff} icon={row.icon}>
                {components.map((c) => {
                  const v = row.get(c);
                  if (v === null || v === undefined) {
                    return (
                      <td key={c.id} className="px-3.5 py-2.5 text-center">
                        <Minus size={13} className="mx-auto text-gray-300" />
                      </td>
                    );
                  }
                  if (typeof v === 'boolean') {
                    return (
                      <td key={c.id} className="px-3.5 py-2.5 text-center">
                        {v ? (
                          <CheckCircle size={14} className="mx-auto text-emerald-500" />
                        ) : (
                          <XCircle size={14} className="mx-auto text-red-400" />
                        )}
                      </td>
                    );
                  }
                  return (
                    <Cell key={c.id} isDiff={isDiff}>
                      {String(v)}
                    </Cell>
                  );
                })}
              </Row>
            );
          })}
        </Section>

        {/* Technical Specifications */}
        {allKeys.length > 0 && (
          <Section title="Technical specifications">
            {allKeys.map((key) => {
              const isDiff = getSpecDiff(allSpecs, key) === 'diff';
              return (
                <Row key={key} label={formatSpecKey(key)} isDiff={isDiff}>
                  {components.map((c) => {
                    const val = c.specs[key];
                    if (val === undefined || val === null) {
                      return (
                        <td key={c.id} className="px-3.5 py-2.5 text-center">
                          <Minus size={13} className="mx-auto text-gray-300" />
                        </td>
                      );
                    }
                    if (typeof val === 'boolean') {
                      return (
                        <td key={c.id} className="px-3.5 py-2.5 text-center">
                          {val ? (
                            <CheckCircle size={14} className="mx-auto text-emerald-500" />
                          ) : (
                            <XCircle size={14} className="mx-auto text-red-400" />
                          )}
                        </td>
                      );
                    }
                    return (
                      <Cell key={c.id} isDiff={isDiff}>
                        {formatSpecValue(val)}
                      </Cell>
                    );
                  })}
                </Row>
              );
            })}
          </Section>
        )}

        {/* Resources & Tags */}
        <Section title="Resources & tags">
          <Row label="Tags" isDiff={false}>
            {components.map((c) => (
              <td key={c.id} className="px-3.5 py-2.5 align-top">
                <div className="flex flex-wrap gap-1 justify-center">
                  {c.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-block bg-blue-50 text-blue-600 border border-blue-200 text-[10px] font-medium rounded-full px-2 py-0.5"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </td>
            ))}
          </Row>
          <Row label="Datasheet" isDiff={false}>
            {components.map((c) => (
              <td key={c.id} className="px-3.5 py-2.5 text-center">
                {c.datasheet_url ? (
                  <a
                    href={c.datasheet_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium"
                  >
                    <ExternalLink size={11} /> View
                  </a>
                ) : (
                  <Minus size={13} className="mx-auto text-gray-300" />
                )}
              </td>
            ))}
          </Row>
        </Section>

        {/* Legend */}
        <div className="flex items-center gap-5 text-[11px] text-gray-400 pb-8 pt-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-amber-100 border border-amber-300 shrink-0" />
            Values differ
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-white border border-gray-200 shrink-0" />
            Values match
          </span>
          <span className="flex items-center gap-1.5">
            <Minus size={11} /> Not available
          </span>
        </div>
      </div>
    </div>
  );
}

/* ─── Internal sub-components ─── */

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      <div className="bg-gray-50 border-b border-gray-100 px-4 py-2">
        <span className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">
          {title}
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <tbody className="divide-y divide-gray-100">{children}</tbody>
        </table>
      </div>
    </div>
  );
}

function Row({
  label,
  isDiff,
  icon,
  children,
}: {
  label: string;
  isDiff: boolean;
  icon?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <tr
      className={cn(
        'transition-colors',
        isDiff ? 'hover:bg-amber-50/40' : 'hover:bg-gray-50/60'
      )}
    >
      {/* Sticky label cell */}
      <td
        className={cn(
          'px-4 py-2.5 text-xs font-medium sticky left-0 z-10 border-r border-gray-100 w-40 min-w-[160px]',
          isDiff ? 'bg-amber-50/70 text-amber-800' : 'bg-white text-gray-500'
        )}
      >
        <div className="flex items-center gap-1.5">
          {/* Diff indicator dot */}
          <span
            className={cn(
              'w-1.5 h-1.5 rounded-full shrink-0',
              isDiff ? 'bg-amber-400' : 'bg-gray-200'
            )}
          />
          {icon && (
            <span className={cn('shrink-0', isDiff ? 'text-amber-500' : 'text-gray-400')}>
              {icon}
            </span>
          )}
          {label}
        </div>
      </td>
      {children}
    </tr>
  );
}

function Cell({
  isDiff,
  children,
}: {
  isDiff: boolean;
  children: React.ReactNode;
}) {
  return (
    <td
      className={cn(
        'px-3.5 py-2.5 text-xs text-center align-middle',
        isDiff ? 'bg-amber-50/40 font-medium text-amber-900' : 'text-gray-700'
      )}
    >
      {children}
    </td>
  );
}